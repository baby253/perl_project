# Perl
Mini project
Project one : HTML / JavaScript. :You will design a small web application GUI, using HTML and JavaScript that does the following:
Project two : Perl / Database :You will write a Perl script to output the contents of a table in a database.


